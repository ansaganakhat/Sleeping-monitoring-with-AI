from django.shortcuts import render
from django.http import StreamingHttpResponse, JsonResponse
import cv2
import mediapipe as mp
import numpy as np

# ---------------- SETTINGS ----------------
EAR_THRESHOLD = 0.25
CLOSED_FRAMES = 30
MAX_FACES = 20

sleeping_count_global = 0

# ---------------- MEDIAPIPE ----------------
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=MAX_FACES,
    refine_landmarks=True
)

LEFT_EYE_IDX = [33,160,158,133,153,144]
RIGHT_EYE_IDX = [362,385,387,263,373,380]

def eye_aspect_ratio(landmarks, eye_indices, shape):
    h, w = shape[:2]
    pts = np.array([[int(landmarks[i].x*w),
                     int(landmarks[i].y*h)] for i in eye_indices])
    A = np.linalg.norm(pts[1]-pts[5])
    B = np.linalg.norm(pts[2]-pts[4])
    C = np.linalg.norm(pts[0]-pts[3])
    return (A+B)/(2.0*C)

cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
closed_eye_frames = {}

# ---------------- PAGES ----------------
def index(request):
    return render(request, "index.html")


# ---------------- VIDEO STREAM ----------------
def generate_frames():
    global sleeping_count_global

    while True:
        success, frame = cap.read()
        if not success:
            break

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_mesh.process(rgb)

        sleeping_count = 0

        if results.multi_face_landmarks:
            for idx, face in enumerate(results.multi_face_landmarks):

                left = eye_aspect_ratio(face.landmark,
                                        LEFT_EYE_IDX, frame.shape)
                right = eye_aspect_ratio(face.landmark,
                                         RIGHT_EYE_IDX, frame.shape)

                ear = (left + right)/2

                if idx not in closed_eye_frames:
                    closed_eye_frames[idx] = 0

                if ear < EAR_THRESHOLD:
                    closed_eye_frames[idx]+=1
                else:
                    closed_eye_frames[idx]=0

                if closed_eye_frames[idx] >= CLOSED_FRAMES:
                    sleeping_count += 1
                    cv2.putText(frame,"SLEEPING",
                                (50,50+idx*30),
                                cv2.FONT_HERSHEY_SIMPLEX,
                                1,(0,0,255),2)

        sleeping_count_global = sleeping_count

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' +
               frame + b'\r\n')


def video_stream(request):
    return StreamingHttpResponse(
        generate_frames(),
        content_type='multipart/x-mixed-replace; boundary=frame'
    )


# ---------------- COUNTER API ----------------
def get_count(request):
    return JsonResponse({"sleeping": sleeping_count_global})